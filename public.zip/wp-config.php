<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          '&q%vUI#H!tvZ)$q8C5p^{}Rg6va])Zf{`9{,D;{D+QIpi^R+XQ wh0pJFj:5CXV>' );
define( 'SECURE_AUTH_KEY',   'wm_8Km#;eP>s![JS^qC8,)VAWt_+U!M^2$^7C#=F6Aq9x7*Zovqdoj:*$W.ez9YZ' );
define( 'LOGGED_IN_KEY',     '$s{<:(iAArO$t edCKlR*vATo/ieJ{xwL|>_%J=?f0-)S2> Y]gOD.BA0$S64t^~' );
define( 'NONCE_KEY',         'W2IuP@&)o_Pd[=nv)R2B UEtS-w:(A&}oHNY* u0@zI`N-s0C*=~d~9G<x/V~JKE' );
define( 'AUTH_SALT',         'uP OHNw`<3W+e~yq$p;!{pP1VA0kK!7v=C&ZY0UDa~ n&V~.Bz  sMlNV(wH9_>2' );
define( 'SECURE_AUTH_SALT',  'NfdiXS=s{4ZS}OT%N%qi$8qjz8oFrXbYQ} FE)q?D#]Cpf7pF&(t3GHfjlysnCOk' );
define( 'LOGGED_IN_SALT',    'vzLSL:C=wQYyKos7TWzX?aq7,:.|UQuF]HW@@fog?A}%pAiP>(q1t3KL%`rtuLb`' );
define( 'NONCE_SALT',        '@qCc9W]7h`e[-,@7sH?xA|$%C@&!}fShhPESbi~(ZFAh=y8 OuEvuJcg%s0OnP?H' );
define( 'WP_CACHE_KEY_SALT', 'x&dS+(XNQzO!LnF*h0iZjr?;3M]kC0D[> ~G S?4b{VE[KDE&/GcWz4gonLG*t1k' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'WP_ENVIRONMENT_TYPE', 'local' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';